var config = {
    map: {
        '*': {
            quickSearch: 'IntegerNet_Solr/js/form-mini',
            filterOptionsLink: 'IntegerNet_Solr/js/filterOptionsLink'
        }
    }
};