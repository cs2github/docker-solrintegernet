<?php
/**
 * integer_net Magento Module
 *
 * @category   IntegerNet
 * @package    IntegerNet_Solr
 * @copyright  Copyright (c) 2016 integer_net GmbH (http://www.integer-net.de/)
 * @author     Fabian Schmengler <fs@integer-net.de>
 */
namespace IntegerNet\SolrSuggest\Resource;

use IntegerNet\Solr\Resource\ServiceBase;

class ServiceSuggest extends ServiceBase
{
    //suggest specific service methods would be added here
}